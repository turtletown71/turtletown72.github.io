package net.minecraft.src;

public class Packet51MapChunkData {
	public byte[] compressedData;
	public int chunkExistFlag;
	public int chunkHasAddSectionFlag;
}
