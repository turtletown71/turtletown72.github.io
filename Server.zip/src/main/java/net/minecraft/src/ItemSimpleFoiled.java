package net.minecraft.src;

public class ItemSimpleFoiled extends Item {
	public ItemSimpleFoiled(int par1) {
		super(par1);
	}
}
