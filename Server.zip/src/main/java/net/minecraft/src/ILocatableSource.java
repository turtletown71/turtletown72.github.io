package net.minecraft.src;

public interface ILocatableSource extends ILocation {
}
