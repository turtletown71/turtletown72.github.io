package net.minecraft.src;

public enum EnumMobType {
	everything, mobs, players;
}
