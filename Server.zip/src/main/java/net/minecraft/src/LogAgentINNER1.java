package net.minecraft.src;

class LogAgentINNER1 {
}
